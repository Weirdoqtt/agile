package com.example.agile

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
